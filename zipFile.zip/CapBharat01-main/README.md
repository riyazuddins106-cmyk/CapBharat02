
  # Urban Clap Mobile App Design

  This is a code bundle for Urban Clap Mobile App Design. The original project is available at https://www.figma.com/design/szBTENGuikiy0mmufGhbcd/Urban-Clap-Mobile-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  